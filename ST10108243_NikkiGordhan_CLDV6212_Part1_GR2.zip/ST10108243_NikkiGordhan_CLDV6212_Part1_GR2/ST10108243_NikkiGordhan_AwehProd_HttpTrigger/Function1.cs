using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

//CLDV PoE Part 1:
//code an Http Trigger that allows users to enter their ID number to see their vaccination history.
namespace ST10108243_NikkiGordhan_AwehProd_HttpTrigger
{
    public static class Function1
    {
        public static string[] sIDNumbers = new string[]
        {
            "9405105021537",
            "9506116231763",
            "9607127862574"
        };
        // creates an array of valid ID numbers.
        // the format of the code above was taken from W3Schools
        // https://www.w3schools.com/cs/cs_arrays.php


        [FunctionName("GetVacinationData")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "id/{IDNumber?}")] HttpRequest req,
            string IDNumber,
            ILogger log)
        // the code to change the route was taken from Microsoft.
        //https://learn.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python-v2%2Cin-process%2Cfunctionsv2&pivots=programming-language-csharp

        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            if (string.IsNullOrEmpty(IDNumber))
            {
                string responseMessage = "Welcome " + '\n' + "Please eneter your ID number into the URL at the top to see you vacinnation history. In the following format:" + '\n'+ "/api/id/9809144918021";
                return new BadRequestObjectResult(responseMessage);
                //welcome message if no id number is entered.
            }
            else 
            {        
                string idno = GenerateVaccinationData(IDNumber);
                //genertaes the information if an id is entered.

                string responseMessage = $"Hello {IDNumber}," + '\n' + idno;
                return new OkObjectResult(responseMessage);
                //gives the user a welcome message.  
            }
        }
        public static string GenerateVaccinationData(string IDNumber)
        {
            if (IDNumber == "9405105021537") return "Date of vacinnation: 21/08/2023" + '\n'
                    + "Name: Varicella" + '\n'
                    + "Expire date: 30/09/2024" + '\n'
                    + "Reason for vaccination: Chicken Pox";
            // returns this information if this id number is entered 9405105021537.

            if (IDNumber == "9506116231763")
                return "Date of vacinnation: 12/06/2023" + '\n'
                    + "Name: Fluzone Quadivalent" + '\n'
                    + "Expire date: 16/03/2024" + '\n'
                    + "Reason for vaccination: Flu";
            // returns this information if this id number is entered 9506116231763.

            if (IDNumber == "9607127862574")
                return "Date of vacinnation: 04/09/2023" + '\n'
                    + "Name: Pfizer-BioNTech" + '\n'
                    + "Expire date: 27/11/2024" + '\n'
                    + "Reason for vaccination: COVID-19";
            // returns this information if this id number is entered 9607127862574.

            //the format of the above if statement were taken from TutorialsPoint
            //https://www.tutorialspoint.com/csharp/if_statement_in_csharp.htm


            return "Please enter valid ID number";
        }
    }
}
